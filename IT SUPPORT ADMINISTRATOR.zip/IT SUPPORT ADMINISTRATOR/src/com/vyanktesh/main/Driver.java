package com.vyanktesh.main;

import java.util.Scanner;

import com.vyanktesh.model.Employee;
import com.vyanktesh.service.CredentialService;

public class Driver {
	
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		Employee employee = new Employee("Vyanktesh" , "Mishra");
		CredentialService cs = new CredentialService();
	     
		 
		 System.out.println("Please enter the department from following");
		 System.out.println("1. Technical");
		 System.out.println("2. Admin");
		 System.out.println("3. Human resource");
		 System.out.println("4. Legal");
		 		
		 int department = sc.nextInt();
		 
	;		  switch(department) {
		 
		 case 1: {
	   			cs.showCredentials(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "technical");
			    break;
		}
		 
		 case 2:{
			    cs.showCredentials(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "admin");
				break;
		 }
			 
		 case 3:{
			    cs.showCredentials(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "humanresource");
                break;
			}
		 case 4:{
			    cs.showCredentials(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "legal");
			
			    break;
		 }
		 
		 default:
			 System.out.println("Please provide the correct option.");
			 break;
		 
	}
		 
		 	 
		
		
	}

}
