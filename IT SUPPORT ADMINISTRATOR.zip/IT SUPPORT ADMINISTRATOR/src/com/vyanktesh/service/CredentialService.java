package com.vyanktesh.service;

import java.util.Random;

public class CredentialService {

	
	private String generatePassword() {
		
	      String capitalLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	      String lowerLetters = "abcdefghijklmnopqrstuvwxyz";
	      String specialCharacters = "!@#$%^&*()[]";
	      String numbers = "0123456789";
	      String combinedChars = capitalLetters + lowerLetters + specialCharacters + numbers;
	      Random random = new Random();
	      char[] password = new char[11];
	   
	      for(int i = 0; i < 11 ; i++) {
	         password[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
	      }
	      return password.toString();
	   }


	public String generateEmailAddress(String firstName , String lastName , String department){
		
			return firstName + lastName+ "@" + department + ".abc.com";  
	}
	
	public void showCredentials(String firstName, String lastName, String department) {
		System.out.println("Dear " +firstName.toUpperCase()+" Your generated credentials are as follows:");
		System.out.println("Email ---- " +generateEmailAddress(firstName, lastName, department));
		System.out.println("Password ---- " +generatePassword());
		
		
		
	}


}